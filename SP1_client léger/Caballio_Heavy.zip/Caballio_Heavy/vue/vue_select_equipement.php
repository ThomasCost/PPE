<h3 class="titre-form">Liste des Équipements</h3>

<table class="tableau">
    <tr>
        <th>ID</th>
        <th>Libellé</th>
        <th>Centre</th>
        <th>Propriétaire (client)</th>
        <th>Date d'ajout</th>
        <?php if ($peutModifier) { ?><th>Actions</th><?php } ?>
    </tr>

    <?php
    mysqli_data_seek($lesLignes, 0);
    foreach ($lesLignes as $ligne) {
        echo "<tr>";
            echo "<td>".htmlspecialchars($ligne['IdEquipement'] ?? '')."</td>";
            echo "<td>".htmlspecialchars($ligne['LibelleEquipement'] ?? '')."</td>";
            echo "<td>".htmlspecialchars($ligne['IdCentre'] ?? '')."</td>";
            echo "<td>".htmlspecialchars($ligne['IdClient'] ?? '')."</td>";
            echo "<td>".htmlspecialchars($ligne['DateAjoutEquipement'] ?? '')."</td>";
        if ($peutModifier) {
            echo "<td class='actions'>";
            echo "<a href='index.php?page=7&action=edit&IdEquipement=".urlencode($ligne['IdEquipement'])."' title='Modifier'>&#9998;</a> ";
            echo "<a href='index.php?page=7&action=sup&IdEquipement=".urlencode($ligne['IdEquipement'])."' title='Supprimer' onclick=\"return confirm('Confirmer la suppression ?');\">&#128465;</a>";
            echo "</td>";
        }
        echo "</tr>";
    }
    ?>
</table>
