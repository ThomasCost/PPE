<h3 class="titre-form">Ajouter : Type de paiement</h3>

<form method="post" class="formulaire">
    <table>
        <tr>
            <td>Libellé :</td>
            <td><input type="text" name="NomTypePayement"></td>
        </tr>
        <tr>
            <td><input type="reset" name="Annuler" value="Annuler"></td>
            <td><input type="submit" name="Valider" value="Valider"></td>
        </tr>
    </table>
</form>
